# Amazon Creators API Node.js SDK

![https://github.com/ryanschiang/amazon-creators-api](https://img.shields.io/badge/github-repo-blue?logo=github) ![https://github.com/ryanschiang/amazon-creators-api/blob/main/LICENSE.txt](https://img.shields.io/github/license/ryanschiang/amazon-creators-api) ![https://github.com/ryanschiang/amazon-creators-api](https://img.shields.io/github/package-json/v/ryanschiang/amazon-creators-api) ![https://npmjs.com/package/amazon-creators-api](https://img.shields.io/npm/v/amazon-creators-api)

This is an **unofficial TypeScript wrapper** for the [Amazon Creators API Node.js SDK](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/get-started/using-sdk).

- [API Reference](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/api-reference)
- [Getting Started](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/get-started/using-sdk)

This package implements a thin TypeScript wrapper around Amazon's JS runtime internals to add proper types to the Node.js SDK.

## Prerequisites

- Node.js version 18 or higher
- [Register](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/onboarding/register-for-creators-api) for the Creators API

## Installation

```bash
npm install amazon-creators-api
```

## Usage

See the [examples](https://github.com/ryanschiang/amazon-creators-api/tree/main/examples) directory for usage examples.

### Get Items

```ts
import {
  ApiClient,
  GetItemsRequestContent,
  GetItemsResource,
  TypedDefaultApi,
} from "amazon-creators-api";

// Initialize API client
const apiClient = new ApiClient();

// Add credential details
// You can find these in the Creators API dashboard: https://affiliate-program.amazon.com/creatorsapi
apiClient.credentialId = "<YOUR CREDENTIAL ID>";
apiClient.credentialSecret = "<YOUR CREDENTIAL SECRET>";
apiClient.version = "<YOUR CREDENTIAL VERSION>";

// Initialize typed API wrapper
const api = new TypedDefaultApi(apiClient);

/**
 * Sample function to demonstrate GetItems API usage
 */
async function getItems(): Promise<void> {
  /**
   * Add marketplace. For more details, refer: https://affiliate-program.amazon.com/creatorsapi/docs/en-us/api-reference/common-request-headers-and-parameters#marketplace-locale-reference
   */
  const marketplace = "<YOUR MARKETPLACE>"; // e.g. "www.amazon.com" for US marketplace

  // Create GetItems request
  // Enter your partner tag (store/tracking id)
  const partnerTag = "<YOUR PARTNER TAG>";

  // Choose item id(s) - ASINs to retrieve
  const itemIds = ["B0DLFMFBJW", "B0BFC7WQ6R", "B00ZV9RDKK"];

  const getItemsRequest = new GetItemsRequestContent(partnerTag, itemIds);

  /**
   * Choose resources you want from GetItemsResource enum
   * For more details, refer: https://affiliate-program.amazon.com/creatorsapi/docs/en-us/api-reference/operations/get-items#resources-parameter
   */
  const resources = [
    "images.primary.medium",
    "itemInfo.title",
    "itemInfo.features",
    "offersV2.listings.price",
    "offersV2.listings.availability",
    "offersV2.listings.condition",
    "offersV2.listings.merchantInfo",
  ].map((resource) => GetItemsResource.constructFromObject(resource));
  getItemsRequest.resources = resources;

  try {
    const response = await api.getItems(marketplace, getItemsRequest);
    console.log("API called successfully.");
    console.log("Complete Response:\n", JSON.stringify(response, null, 2));
  } catch (error) {
    console.log("Error calling Creators API!");
    console.log("Full Error Object:\n", JSON.stringify(error, null, 2));
  }
```

## Contributing

Contributions are welcome! Please open an [issue](https://github.com/ryanschiang/amazon-creators-api/issues) or submit a pull request.

## License

Licensed under the Apache License, Version 2.0. See the [https://github.com/ryanschiang/amazon-creators-api/blob/main/LICENSE.txt](LICENSE) file for details.

Original authorship belongs to Amazon.com, Inc. or its affiliates. See the [https://github.com/ryanschiang/amazon-creators-api/blob/main/NOTICE.txt](NOTICE.txt) file for details.

Modifications copyright (c) 2026 Ryan Chiang.
